//c program to print numbers foom 1 to n

#include<stdio.h>
int main(){
    int n ;

    printf("enter number :");
    scanf("%d",&n);

    for(int i =1;i<=n;i++){
        printf("%d\n",i);
    }
}