// write a simple program for print hello world 
#include<stdio.h>
int main() {
    printf("hello world");
    return 0;
}