
//c program to multiply two floating numbers

#include<stdio.h>
int main(){
    float a = 5.76;
    float b = 6.87;

    float multiplication = a*b;
    printf("multiplication is :%2f",multiplication);

}