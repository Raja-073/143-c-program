//c program to add two numbers 

#include<stdio.h>
void main(){
    int a,b,sum;
    printf("enter two numbers:\n");
    scanf("%d %d",&a,&b);

    sum = a+b;
    printf("total sum is :%d",sum);
}
