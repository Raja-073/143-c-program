//c program to print an integer entered by the user

#include<stdio.h>
int main(){
    int number;
    printf("enter a number :");
    scanf("%d",&number);

    printf("the number entered by the user is : %d",number); 
    return 0;

}