//char to int 
#include <stdio.h>

int main() {
    char ch = 'A';
    int num = (int)ch;

    printf("Integer representation: %d\n", num);

    return 0;
}
