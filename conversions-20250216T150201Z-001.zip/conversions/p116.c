//decimal to hecadecimal
#include <stdio.h>

int main() {
    int decimalNum = 26;

    printf("Hexadecimal representation: %X\n", decimalNum);

    return 0;
}
