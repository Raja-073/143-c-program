//decimal to octal
#include <stdio.h>

int main() {
    int decimalNum = 15;
    
    printf("Octal representation: %o\n", decimalNum);

    return 0;
}
