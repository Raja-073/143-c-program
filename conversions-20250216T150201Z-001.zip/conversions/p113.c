//octal to decimal
#include <stdio.h>

int main() {
    int octalNum = 017;  
    int decimalNum = 0;

    decimalNum = octalNum;
    printf("Decimal representation: %d\n", decimalNum);

    return 0;
}
