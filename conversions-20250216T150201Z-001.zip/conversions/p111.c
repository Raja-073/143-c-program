//int to char
#include <stdio.h>

int main() {
    int num = 65;
    char ch = (char)num;

    printf("Character representation: %c\n", ch);

    return 0;
}
