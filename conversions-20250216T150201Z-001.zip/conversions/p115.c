//hexadecimal to decimal
#include <stdio.h>

int main() {
    int hexNum = 0x1A;  // Hexadecimal number (prefix 0x)
    int decimalNum = hexNum;

    printf("Decimal representation: %d\n", decimalNum);

    return 0;
}
