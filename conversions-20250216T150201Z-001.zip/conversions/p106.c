//boolean to string conversion 
#include <stdio.h>

int main() {
    int booleanValue = 1; 
    if (booleanValue)
        printf("true\n");
    else
        printf("false\n");
    return 0;
}
