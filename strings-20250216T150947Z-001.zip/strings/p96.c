//find the length of a string
#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "hello";
    printf("Length of the string: %d\n", strlen(str));
    return 0;
}
